package com.beifeng.sooba.db.admin;

public interface AdminDao {
	public User getAdmin(String name,String pwd);
}
