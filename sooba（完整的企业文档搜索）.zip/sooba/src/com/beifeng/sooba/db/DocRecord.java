package com.beifeng.sooba.db;

import java.util.Date;

public class DocRecord {
	
	private Integer id;
	private String filename;
	private String doctype;
	private Long lastmodify;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getFilename() {
		return filename;
	}
	public void setFilename(String filename) {
		this.filename = filename;
	}


	public String getDoctype() {
		return doctype;
	}
	public void setDoctype(String doctype) {
		this.doctype = doctype;
	}
	public Long getLastmodify() {
		return lastmodify;
	}
	public void setLastmodify(Long lastmodify) {
		this.lastmodify = lastmodify;
	}


}
